<nav id="navbar">
         <ul class="titrepage">
            <li><a href="">Kunu.</a></li>
        </ul>

</nav>

<script src="app.js"></script>
<script src="headereffect.js"></script>