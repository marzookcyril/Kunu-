<div class="footer">
        <div class="inner">
            <div class="logo">

            </div>
            <div class="txtfooter">
                <h6>Tous droits réservés Kunu.</h6>
            </div>
            <div class="links">
                    <a href="#" class="">Facebook</a>
                    <a href="#" class="">Twitter</a>
                    <a href="kunu2.php#contact" class="">Nous Contacter</a>
                    <a href="#" class="">FAQ</a>
            </div>
        </div>
</div>