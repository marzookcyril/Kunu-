<nav id="navbar">
         <ul class="titrepage">
            <li><a href="kunu2.php">Kunu.</a></li>
        </ul>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <ul class="nav-links">
            <li><a href="kunu2.php#actualités">Actualités</a></li>
            <li><a href="kunu2.php#calendrier">Calendrier</a></li>
            <li><a href="../bouhtique.php">Boutique</a></li>
            <li><a href="kunu2.php#contact">Contact</a></li>
                        
            <li class="nav-item dropdown menu"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Voyager</a>
                <ul> 
                    <li class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="../reserver.php">Réserver</a>
                        <a class="dropdown-item" href="../creer.php">Créer un séjour</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item dropdown menu"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mon compte</a>
                <ul> 
                    <li class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="../Accueil.php">Tchat</a>
                        <a class="dropdown-item" href="../info.php">Mes infos</a>
                        <a class="dropdown-item" href="../pagePanier.php">Panier</a>
                        <a class="dropdown-item" href="../deconnexion.php">Déconnexion</a>
                    </li>
                </ul>
            </li>
        </ul>
</nav>

<script src="app.js"></script>
<script src="headereffect.js"></script>